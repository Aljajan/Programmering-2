package no.hiof.almuthanna;


import java.util.ArrayList;

public class Main {


    public static void main(String[] args) {
        //Oppgave 2.2
        Planet mercuryPlanet = new Planet("Mercury", 3.283E23, 2439.7);
        Planet venusPlanet = new Planet("Venus", 4.867E24, 6051.8);
        Planet earthPlanet = new Planet("Earth", 5.972E24, 6371);
        Planet marsPlanet = new Planet("Mars", 6.39E23, 3389.5);
        Planet jupiterPlanet = new Planet("Jupiter", 1.898E27, 69911);
        Planet saturnPlanet = new Planet("Saturn", 5.683E26, 58232);
        Planet uranusPlanet = new Planet("Uranus", 8.681E25, 25362);
        Planet neptunePlanet = new Planet("Neptune", 1.024E26, 24622);
        Star sunStar = new Star("Sun", 1.9885E30, 695342, 5777);
        ArrayList<Planet> planets = new ArrayList<>();
        planets.add(mercuryPlanet);
        planets.add(venusPlanet);
        planets.add(earthPlanet);
        planets.add(marsPlanet);
        planets.add(jupiterPlanet);
        planets.add(saturnPlanet);
        planets.add(uranusPlanet);
        planets.add(neptunePlanet);
        PlanetSystem solarSystem = new PlanetSystem("Solar System", sunStar, planets);

        System.out.println("\n************* Oppgave 2.3 ************");

        System.out.println(solarSystem.toString());
        System.out.println(sunStar.toString());
        System.out.println(mercuryPlanet.toString());
        System.out.println(earthPlanet.toString());
        System.out.println(uranusPlanet.toString());

        System.out.println("\n************* Oppgave 2.4 ************");

        System.out.println("\n************* Mjup og Rjup for \"Saturn\" ************");
        System.out.println(saturnPlanet.mjPlanet());
        System.out.println(saturnPlanet.rjPlanet());
        System.out.println("\n************* Msun og Rsun for vår stjerne \"Sun\" ************");
        System.out.println(sunStar.msunStar());
        System.out.println(sunStar.rsunStar());
        System.out.println("\n************* Oppgave 2.5 ************");

        System.out.println("\n************* Surface gravity til Neptune ************");
        System.out.println(neptunePlanet.surfaceGravity());

        System.out.println("\n************* Oppgave 2.6 ************");

        System.out.println("\n************* Største  planeten i PlanetSystemet ************");
        System.out.println(solarSystem.storstePlanetenIsolarSystem(planets));
        System.out.println("\n************* Minste planeten i PlanetSystemet ************");
        System.out.println(solarSystem.minstePlanetenIsolarSystem(planets));

    }
}





