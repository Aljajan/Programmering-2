package no.hiof.almuthanna;

public class Star extends Planet {

    private double effectiveTemp;

    public Star(String name, double mass, double radius, double effectiveTemp) {
        super(name, mass, radius);
        this.effectiveTemp = effectiveTemp;
    }

    public double getEffectiveTemp() {
        return effectiveTemp;
    }

    public void setEffectiveTemp(double effectiveTemp) {
        this.effectiveTemp = effectiveTemp;
    }

    @Override
    public String toString() {
        return "Stjernen informasjon: navn er " + super.getName() + ", radius = " + super.getRadius() + " km, mass = " + super.getMass() + " kg, effectiveTemp = " + effectiveTemp + " K.";
    }

    public String msunStar() {
        double mSun = this.getMass() / 1.98892E30;
        return "Masse for " + this.getName() + " er: " + mSun + " Msun";
    }

    public String rsunStar() {
        double rSun = this.getRadius() / 695700;
        return "Størrelse for " + this.getName() + " er: " + rSun + " Rsun";
    }


}
