package no.hiof.almuthanna;

public class Planet {
    private String name;
    private double mass;
    private double radius;

    public Planet(String name, double mass, double radius) {
        this.name = name;
        this.mass = mass;
        this.radius = radius;
    }

    public String getName() {
        return name;
    }

    public double getMass() {
        return mass;
    }

    public double getRadius() {
        return radius;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    @Override
    public String toString() {
        return "Planet navn er " + name + ", mass= " + mass + " kg, radius= " + radius + " km";
    }

    public String mjPlanet() {
        double mJup = this.getMass() / 1.898E27;
        return "Masse for planeten " + this.getName() + " er: " + mJup + " Mjup";
    }

    public String rjPlanet() {
        double rJup = this.getRadius() / 71492;
        return "Størrelse for planeten " + this.getName() + " er: " + rJup + " Rjup";
    }

    public String surfaceGravity() {
        double gravitasjonKonstanten = 0.00000000006674;
        double surfaceGr = ( gravitasjonKonstanten * this.getMass() ) / ( Math.pow(( this.getRadius() * 1000 ), 2) );
        return "Surface gravity til " + this.getName() + " er: " + surfaceGr + " g.";
    }


}



