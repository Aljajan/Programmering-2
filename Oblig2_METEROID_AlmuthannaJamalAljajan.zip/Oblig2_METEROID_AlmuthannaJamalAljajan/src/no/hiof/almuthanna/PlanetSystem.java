package no.hiof.almuthanna;

import java.util.ArrayList;

public class PlanetSystem {
    private String name;
    private Star centerStar;
    private ArrayList<Planet> planets;


    public PlanetSystem(String name, Star centerStar, ArrayList<Planet> planets) {
        this.name = name;
        this.centerStar = centerStar;
        this.planets = planets;
    }

    public String getName() {
        return name;
    }

    public Star getCenterStar() {
        return centerStar;
    }

    public ArrayList<Planet> getPlanets() {
        return planets;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCenterStar(Star centerStar) {
        this.centerStar = centerStar;
    }

    public void setPlanets(ArrayList<Planet> planets) {
        this.planets = planets;
    }

    @Override
    public String toString() {
        return "PlanetSystem navn er " + name + ".\n" + centerStar + "\n" + "Planeter informasjon: " + "\n" + planets;
    }

    public Planet storstePlanetenIsolarSystem(ArrayList<Planet> planets) {
        Planet storstePlaneten = planets.get(0);
        for (int i = 0; i < planets.size(); i++) {
            if (planets.get(i).getRadius() > storstePlaneten.getRadius()) {
                storstePlaneten = planets.get(i);
            } else if (planets.get(i).getRadius() == storstePlaneten.getRadius()) {
                for (int j = 0; j < planets.size(); j++)
                    if (planets.get(j).getMass() > storstePlaneten.getMass()) {
                        storstePlaneten = planets.get(j);
                    }
            }
        }
        return storstePlaneten;
    }

    public Planet minstePlanetenIsolarSystem(ArrayList<Planet> planets) {
        Planet minstePlaneten = planets.get(0);
        for (int i = 0; i < planets.size(); i++) {
            if (planets.get(i).getRadius() < minstePlaneten.getRadius()) {
                minstePlaneten = planets.get(i);
            } else if (planets.get(i).getRadius() == minstePlaneten.getRadius()) {
                for (int j = 0; j < planets.size(); j++)
                    if (planets.get(j).getMass() < minstePlaneten.getMass()) {
                        minstePlaneten = planets.get(j);
                    }
            }
        }
        return minstePlaneten;
    }


}
