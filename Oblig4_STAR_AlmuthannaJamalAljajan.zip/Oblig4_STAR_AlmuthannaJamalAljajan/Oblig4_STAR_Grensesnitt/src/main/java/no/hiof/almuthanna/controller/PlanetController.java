package no.hiof.almuthanna.controller;

import io.javalin.http.Context;
import no.hiof.almuthanna.model.Planet;
import no.hiof.almuthanna.model.PlanetSystem;
import no.hiof.almuthanna.repository.IUniverseRepository;

import java.util.ArrayList;
import java.util.Collections;

public class PlanetController {
    private IUniverseRepository planetSystemRepository;

    public PlanetController(IUniverseRepository planetSystemRepository) {
        this.planetSystemRepository = planetSystemRepository;
    }
    public void getAllPlanetSystems(Context ctx){
        ArrayList<PlanetSystem> allPlanetSystems =planetSystemRepository.getAllPlanetSystems();
        ctx.json(allPlanetSystems);
    }
    public void getSpecificPlanetSystem(Context ctx){
        String planetSystemId = ctx.pathParam(":planet-system-id");
        PlanetSystem specificPlanetSystem = planetSystemRepository.getSpecificPlanetSystem(planetSystemId);
        ctx.json(specificPlanetSystem);
    }

    public void getPlanetInSpecificPlanetSystem(Context ctx){
        String planetSystemId = ctx.pathParam(":planet-system-id");
        String planetId = ctx.pathParam(":planet-id");

        Planet planetInSpecificPlanetSystem = planetSystemRepository.getPlanetInSpecificPlanetSystem(planetSystemId,planetId);
        ctx.json(planetInSpecificPlanetSystem);
    }



    public void getAllPlanets(Context context) {
        String planetSystemID = context.pathParam(":planet-system-id");
        String sortBy = context.queryParam("sort_by");

        ArrayList<Planet> allPlanets = planetSystemRepository.getAllPlanetsInSpecificPlanetSystem(planetSystemID);

        if (sortBy != null) {
            switch (sortBy) {
               case "name":
                    Collections.sort(allPlanets);
                    break;
                case "mass":
                    allPlanets.sort((planet1, planet2) -> (int)(planet1.getMass() - planet2.getMass()));
                    break;
                case "radius":
                    allPlanets.sort((planet1, planet2) -> (int)(planet1.getRadius() - planet2.getRadius()));
                    break;
            }
        }

        context.json(allPlanets);
    }



}
