package no.hiof.almuthanna.model;

public class NaturalSatellite extends CelestialBody {
    private double semiMajorAxis;
    private double eccentricity;
    private int orbitalPeriod;
    private CelestialBody centralCelestialBody;
    private static final double AVSTANDEN_IN_AU = 149597871;
    private static final double CONVERT_KM_TIL_M = 1000;



    public NaturalSatellite(String name, double mass, double radius, double semiMajorAxis, double eccentricity, int orbitalPeriod, CelestialBody centralCelestialBody ) {
        super(name, mass, radius);
        this.semiMajorAxis = semiMajorAxis;
        this.eccentricity = eccentricity;
        this.orbitalPeriod = orbitalPeriod;
        this.centralCelestialBody = centralCelestialBody;
    }

    public NaturalSatellite(String name, double mass, double radius, double semiMajorAxis, double eccentricity, int orbitalPeriod, CelestialBody centralCelestialBody, String pictureUrl) {
        super(name, mass, radius, pictureUrl);
        this.semiMajorAxis = semiMajorAxis;
        this.eccentricity = eccentricity;
        this.orbitalPeriod = orbitalPeriod;
        this.centralCelestialBody = centralCelestialBody;
    }

    public double getSemiMajorAxis() {
        return semiMajorAxis;
    }

    public double getEccentricity() {
        return eccentricity;
    }

    public int getOrbitalPeriod() {
        return orbitalPeriod;
    }

    public CelestialBody getCentralCelestialBody() {
        return centralCelestialBody;
    }

    public static double getAvstandenInAu() {
        return AVSTANDEN_IN_AU;
    }

    public static double getConvertKmTilM() {
        return CONVERT_KM_TIL_M;
    }

    public void setSemiMajorAxis(double semiMajorAxis) {
        this.semiMajorAxis = semiMajorAxis;
    }

    public void setEccentricity(double eccentricity) {
        this.eccentricity = eccentricity;
    }

    public void setOrbitalPeriod(int orbitalPeriod) {
        this.orbitalPeriod = orbitalPeriod;
    }

    public void setCentralCelestialBody(Star centralCelestialBody) {
        this.centralCelestialBody = centralCelestialBody;
    }

    public double distanceToCentralBody(double degrees) {
        double angelInRadians = Math.toRadians(degrees);
        double distance = ( this.getSemiMajorAxis() * ( 1 - ( Math.pow(this.getEccentricity(), 2) ) ) / ( 1 + ( ( this.getEccentricity() ) * ( Math.cos(angelInRadians) ) ) ) );
        double distanceInKm = distance * AVSTANDEN_IN_AU;
        return distanceInKm;
    }

    public double orbitingVelocity(double degrees) {
        double distance = this.distanceToCentralBody(degrees);
        double speed = ( Math.sqrt(( Planet.getGravitationalConstant()* this.getCentralCelestialBody().getMass() ) / distance * CONVERT_KM_TIL_M))* 0.000001;
        return speed;
    }

    @Override
    public String toString() {
        return "NaturalSatellite: semiMajorAxis=" + semiMajorAxis + ", eccentricity=" + eccentricity + ", orbitalPeriod=" + orbitalPeriod + ", centralCelestialBody=" + centralCelestialBody;
    }
}
