package no.hiof.almuthanna.model;

public class Star extends CelestialBody {

    private double effectiveTemperature;
    private static final double MASS_IN_MSUN = 1.98892E30;
    private static final double RADIUS_IN_RSUN = 695700;

    public Star(String name, double mass, double radius, double effectiveTemperature) {
        super(name, mass, radius);
        this.effectiveTemperature = effectiveTemperature;
    }

    public double getEffectiveTemperature() {
        return effectiveTemperature;
    }
    public static double getMASS_IN_MSUN() {
        return MASS_IN_MSUN;
    }

    public static double getRadiusInRsun() {
        return RADIUS_IN_RSUN;
    }

    public void setEffectiveTemperature(double effectiveTemperature) {
        this.effectiveTemperature = effectiveTemperature;
    }

    @Override
    public String toString() {
        return String.format("%s has a radius of %.2fkm, a mass of %.2fkg and a effective temperature of %.2fK", super.getName(), super.getRadius(), super.getMass(), effectiveTemperature);
    }

    public double getMassInMsun() {
        return super.getMass() / MASS_IN_MSUN;
    }

    public double getReadiusInRsun() {
        return super.getRadius() / RADIUS_IN_RSUN;
    }
}
