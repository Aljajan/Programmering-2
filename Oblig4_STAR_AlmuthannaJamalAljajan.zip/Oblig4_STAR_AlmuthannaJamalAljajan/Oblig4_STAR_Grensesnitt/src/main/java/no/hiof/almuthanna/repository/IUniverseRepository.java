package no.hiof.almuthanna.repository;

import no.hiof.almuthanna.model.Planet;
import no.hiof.almuthanna.model.PlanetSystem;

import java.util.ArrayList;

public interface IUniverseRepository {

    ArrayList<PlanetSystem> getAllPlanetSystems();

    PlanetSystem getSpecificPlanetSystem(String planetSystemName);

    ArrayList<Planet> getAllPlanetsInSpecificPlanetSystem(String planetSystemName);

    Planet getPlanetInSpecificPlanetSystem(String planetSystemName, String planetName);
}
