package no.hiof.almuthanna.repository;

import no.hiof.almuthanna.model.Planet;
import no.hiof.almuthanna.model.PlanetSystem;
import no.hiof.almuthanna.model.Star;

import java.util.ArrayList;

public class UniverseRepository implements IUniverseRepository {

    private ArrayList<PlanetSystem> planetSystem= new ArrayList<>();

    public UniverseRepository() {
        //SolarSystem
        Star star = new Star("Sun", 695700, 1.98892E30, 5777);
        PlanetSystem solarSystem = new PlanetSystem("SolarSystem", star,"https://upload.wikimedia.org/wikipedia/commons/c/c3/Solar_sys8.jpg");
        // Instansierer og legger planetene direkte til i planetsystemet
        solarSystem.addPlanet(new Planet("Mercury", 3.283E23, 2439.7, 0.387, 0.206, 88, star,"https://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Transit_Of_Mercury%2C_May_9th%2C_2016.png/480px-Transit_Of_Mercury%2C_May_9th%2C_2016.png"));
        solarSystem.addPlanet(new Planet("Venus", 4.867E24, 6051.8, 0.723, 0.007, 225, star, "https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/SDO%27s_Ultra-high_Definition_View_of_2012_Venus_Transit_%28304_Angstrom_Full_Disc_02%29.jpg/480px-SDO%27s_Ultra-high_Definition_View_of_2012_Venus_Transit_%28304_Angstrom_Full_Disc_02%29.jpg"));
        solarSystem.addPlanet(new Planet("Earth", 5.972E24, 6371, 1, 0.017, 365, star, "https://upload.wikimedia.org/wikipedia/commons/thumb/a/aa/NASA_Earth_America_2002.jpg/480px-NASA_Earth_America_2002.jpg"));
        solarSystem.addPlanet(new Planet("Mars", 6.39E23, 3389.5, 1.524, 0.093, 687, star,"https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Mars_23_aug_2003_hubble.jpg/480px-Mars_23_aug_2003_hubble.jpg"));
        solarSystem.addPlanet(new Planet("Jupiter", 1.898E27, 71492, 5.20440, 0.049, 4380, star, "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Jupiter_and_its_shrunken_Great_Red_Spot.jpg/480px-Jupiter_and_its_shrunken_Great_Red_Spot.jpg"));
        solarSystem.addPlanet(new Planet("Saturn", 5.683E26, 58232, 9.5826, 0.057, 10585, star, "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/Saturn_from_Cassini_Orbiter_-_Square_%282004-10-06%29.jpg/480px-Saturn_from_Cassini_Orbiter_-_Square_%282004-10-06%29.jpg"));
        solarSystem.addPlanet(new Planet("Uranus", 8.681E25, 25362, 19.2184, 0.046, 30660, star, "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/Uranus2.jpg/480px-Uranus2.jpg"));
        solarSystem.addPlanet(new Planet("Neptune", 1.024E26, 24622, 30.11, 0.010, 60225, star, "https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/Neptune_Full_%28cropped%29.jpg/480px-Neptune_Full_%28cropped%29.jpg"));

        Planet mercury = solarSystem.getPlanets().get(0);
        Planet venus = solarSystem.getPlanets().get(1);
        Planet earth = solarSystem.getPlanets().get(2);
        Planet mars = solarSystem.getPlanets().get(3);
        Planet jupiter = solarSystem.getPlanets().get(4);
        Planet saturn = solarSystem.getPlanets().get(5);
        Planet uranus = solarSystem.getPlanets().get(5);
        Planet neptune = solarSystem.getPlanets().get(7);
        // KeplerSystem
        Star theKepler = new Star("Kepler-11",1.889E30,710310,5680);
        PlanetSystem keplerSystem = new PlanetSystem("KaplerSystem",theKepler,"https://upload.wikimedia.org/wikipedia/commons/6/64/Kepler11.png");
        keplerSystem.addPlanet(new Planet("Kepler-11b",2.56796E25,12550,1.36134E7,0.045,10,theKepler,"https://upload.wikimedia.org/wikipedia/commons/7/76/Kepler-11b_%28Exoplanete%29.jpg"));
        keplerSystem.addPlanet(new Planet("Kepler-11c",8.0622E25,20068,1.5857E7,0.026,13,theKepler, "https://upload.wikimedia.org/wikipedia/commons/c/c9/Kepler-11c_%28Exoplanete%29.jpg"));
        keplerSystem.addPlanet(new Planet("Kepler-11d",3.64292E25,21852,2.3786E7,0.004,22,theKepler,"https://upload.wikimedia.org/wikipedia/commons/6/6f/Kepler-11d_%28Exoplanete%29.jpg"));
        keplerSystem.addPlanet(new Planet("Kepler-11e",5.01648E25,28796,2.9021E7,0.012,31,theKepler, "https://upload.wikimedia.org/wikipedia/commons/f/fa/Kepler-11e_%28Exoplanete%29.jpg"));
        keplerSystem.addPlanet(new Planet("Kepler-11f",1.37356E25,16628,3.7399E7,0.013,36,theKepler,"https://upload.wikimedia.org/wikipedia/commons/1/19/Kepler-11f_%28Exoplanete%29.jpg"));
        keplerSystem.addPlanet(new Planet("Kepler-11g",1.7916E27,23317,6.9114E7,0.015,118,theKepler, "https://upload.wikimedia.org/wikipedia/commons/3/30/Kepler-11g_%28Exoplanete%29.jpg"));

        Planet keplerb = keplerSystem.getPlanets().get(0);
        Planet keplerc= keplerSystem.getPlanets().get(1);
        Planet keplerd= keplerSystem.getPlanets().get(2);
        Planet keplere= keplerSystem.getPlanets().get(3);
        Planet keplerf= keplerSystem.getPlanets().get(4);
        Planet keplerg= keplerSystem.getPlanets().get(5);
        planetSystem.add(solarSystem);
        planetSystem.add(keplerSystem);

    }

    @Override
    public ArrayList<PlanetSystem> getAllPlanetSystems() {
        return planetSystem;
    }

    @Override
    public PlanetSystem getSpecificPlanetSystem(String planetSystemName) {
        for (PlanetSystem enPlanetSystem:planetSystem) {
            if(enPlanetSystem.getName().equals(planetSystemName))
                return enPlanetSystem;

        }
        return null;
    }

    @Override
    public ArrayList<Planet> getAllPlanetsInSpecificPlanetSystem(String planetSystemName) {

        for (int i=0; i< planetSystem.size();i++) {
            if (planetSystemName.equals(planetSystem.get(i).getName()))
                return planetSystem.get(i).getPlanets();
        }
            return null;
    }

    @Override
    public Planet getPlanetInSpecificPlanetSystem(String planetSystemName, String planetName) {

     for (int i=0; i< planetSystem.size();i++) {
            if (planetSystemName.equals(planetSystem.get(i).getName())) {
                for (int j = 0; j <planetSystem.get(i).getPlanets().size();j++) {
                    if (planetName.equals(planetSystem.get(i).getPlanets().get(j).getName()))
                    return planetSystem.get(i).getPlanets().get(j);
                }
            }
        }
        return null;
    }




}

