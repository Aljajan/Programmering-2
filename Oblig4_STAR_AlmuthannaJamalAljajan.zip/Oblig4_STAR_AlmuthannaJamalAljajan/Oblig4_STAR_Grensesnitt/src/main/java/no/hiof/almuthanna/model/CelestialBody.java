package no.hiof.almuthanna.model;

import org.jetbrains.annotations.NotNull;

public abstract class CelestialBody implements Comparable<CelestialBody>{
    private String name;
    private double mass;
    private double radius;
    private String pictureUrl;

    public CelestialBody(String name, double mass, double radius) {
        this.name = name;
        this.mass = mass;
        this.radius = radius;
    }
    public CelestialBody(String name, double mass, double radius, String pictureUrl) {
        this(name, mass, radius);
        this.pictureUrl= pictureUrl;
    }

    public String getName() {
        return name;
    }

    public double getMass() {
        return mass;
    }

    public double getRadius() {
        return radius;
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }

    @Override
    public String toString() {
        return "CelestialBody: name= " + name  + ", mass=" + mass + ", radius=" + radius;
    }

    @Override
    public int compareTo(@NotNull CelestialBody celesialBody) {
            return this.getName().compareTo(celesialBody.getName());
        }


/* @Override
    public int compareTo(CelestialBody celetial) {
        return (int)(this.mass - celetial.getMass());
    }*/
}
