package no.hiof.almuthanna;

public abstract class CelestialBody implements Comparable<CelestialBody>{
    private String name;
    private double mass;
    private double radius;

    public CelestialBody(String name, double mass, double radius) {
        this.name = name;
        this.mass = mass;
        this.radius = radius;
    }

    public String getName() {
        return name;
    }

    public double getMass() {
        return mass;
    }

    public double getRadius() {
        return radius;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    @Override
    public String toString() {
        return "CelestialBody: name= " + name  + ", mass=" + mass + ", radius=" + radius;
    }

    @Override
    public int compareTo(CelestialBody celesialBody) {
        return this.getName().compareTo(celesialBody.getName());
    }
}
