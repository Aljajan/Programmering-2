<template id="observation-create" @planet-submitted="createObservation">
    <div class="form-style">
        <h2>Create new Observation</h2>
        <form class="create" @submit="checkForm" :action=`/api/observations/${observationName}/create` method="post">
            <div v-if="errors.length">
                <b>Please correct the following error(s):</b>
                <ul>
                    <li v-for="error in errors">{{ error }}</li>
                </ul>
            </div>
            <p>
                <label for="name">Name<label>
                    <input type="text" name="name" id="name" v-model="name">
            </p>

            <p>
                <label for="animalName">Animal name<label>
                    <input type="text"  name="animalName" id="animalName" v-model="animalName" >
            </p>
            <p>
                <label for="scientificGroup">ScientificGroup, you must specify on of these types bird/amphibian/invertebrate here.<label>
                    <input type="text"  name="scientificGroup" id="scientificGroup" v-model="scientificGroup" >
            </p>
            <p>
                <label for="gender">Animal gender<label>
                    <input type="text"  name="gender" id="gender" v-model="gender" >
            </p>

            <p>
                <label for="diet">Animal diet<label>
                    <input type="text"  name="diet" id="diet" v-model="diet">
            </p>
            <p>
                <label for="animalPictureURL">Animal pictureURL<label>
                    <input type="url"  name="animalPictureURL" id="animalPictureURL" v-model="animalPictureURL">
            </p>

            <p>
                <label for="animalPro1">Animal Property1, if the animal was a bird specify the wings length (Number) here.<label>
                    <input type="text"  name="animalPro1" id="animalPro1" v-model="animalPro1">
            </p>
            <p>
                <label for="animalPro2">Animal Property2, if the animal was a amphibian specify the number of legs (Number) here.<label>
                    <input type="text"  name="animalPro2" id="animalPro2" v-model="animalPro2">
            </p>
            <p>
                <label for="planetName">Planet name<label>
                    <input type="text"  name="planetName" id="planetName" v-model="planetName">
            </p>
            <p>
                <label for="planetSystemName">PlanetSystem name<label>
                    <input type="text"  name="planetSystemName" id="planetSystemName" v-model="planetSystemName">
            </p>

            <p>
                <label for="latitude">Latitude<label>
                    <input type="number" step="0.000001" name="latitude" id="latitude" v-model="latitude" min="0">
            </p>
            <p>
                <label for="longitude">Longitude<label>
                    <input type="number" step="0.000001" name="longitude" id="longitude" v-model="longitude" min="0">
            </p>
            <p>
                <label for="biomes">Biomes, if the location has more than type of biomes, write the types and separate between them by -<label>
                    <input type="text"  name="biomes" id="biomes" v-model="biomes">

            </p>

            <p>
                <label for="date">Date<label>
                    <input type="date" name="date" id="date" v-model="date">
            </p>
            <p>
                <label for="numberOfAnimals">Number of animals<label>
                    <input type="number"  name="numberOfAnimals" id="numberOfAnimals" v-model="numberOfAnimals" min="0">
            </p>
            <p>
                <label for="pictureURL">Picture Url<label>
                    <input type="url"name="pictureURL" id="pictureURL" v-model="pictureURL" >
            </p>
            <p>
                <label for="comment">Comments<label>
                    <input type="text"name="comment" id="comment" v-model="comment" >
            </p>
            <p>
                <input type="submit" value="Create Observation">
            </p>

        </form>
    </div>

</template>
<script>
    Vue.component("observation-create", {
        template: "#observation-create",
        data: () => ({
            name: null,
            animalName: null, scientificGroup: null,gender: null,diet: null,animalPictureURL: null,animalPro1: null,animalPro2: null,
            planetName: null, planetSystemName: null,latitude: null,longitude: null, biomes: null,
            date: null,
            numberOfAnimals: null,
            pictureURL: null,
            comment: null,
            errors: []
        }),created() {
            this.observationName = this.$javalin.pathParams["observation-id"];
        },
        methods:{
            checkForm:function(e) {
                const urlRegex = "/^(?:(?:(?:https?|ftp):)?\\/\\/)(?:\\S+(?::\\S*)?@)?(?:(?!(?:10|127)(?:\\.\\d{1,3}){3})(?!(?:169\\.254|192\\.168)(?:\\.\\d{1,3}){2})(?!172\\.(?:1[6-9]|2\\d|3[0-1])(?:\\.\\d{1,3}){2})(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[1-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\\.(?:[a-z\u00a1-\uffff]{2,})))(?::\\d{2,5})?(?:[/?#]\\S*)?$/i";
                if(this.name && this.animalName && this.pictureURL) return true;
                this.errors = [];
                if (!this.name) this.errors.push("Name required");
                if (!this.animalName) this.errors.push("animalName required");
                if (!this.pictureURL) this.errors.push("pictureURL required");
                e.preventDefault();
            }
        }
    });
</script>
<style>
    .form-style{
        font-family: 'Open Sans Condensed', arial, sans;
        width: 500px;
        padding: 30px;
        background: #191919;
        margin: 50px auto;
        box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.22);
        -moz-box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.22);
        -webkit-box-shadow:  0px 0px 15px rgba(0, 0, 0, 0.22);
        border: #dddddd;
    }
    .form-style h2{
        background: #4D4D4D;
        text-transform: uppercase;
        font-family: 'Open Sans Condensed', sans-serif;
        color: #FFFFFF;
        font-size: 18px;
        font-weight: 100;
        padding: 20px;
        margin: -30px -30px 30px -30px;
    }
    .form-style input[type="text"],
    .form-style input[type="date"],
    .form-style input[type="datetime"],
    .form-style input[type="email"],
    .form-style input[type="number"],
    .form-style input[type="search"],
    .form-style input[type="time"],
    .form-style input[type="url"],
    .form-style input[type="password"],
    .form-style textarea,
    .form-style select
    {
        box-sizing: border-box;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        outline: none;
        display: block;
        width: 100%;
        padding: 7px;
        border: none;
        color: white;
        border-bottom: 1px solid #ddd;
        background: transparent;
        margin-bottom: 10px;
        font: 16px Arial, Helvetica, sans-serif;
        height: 45px;
    }
    .form-style textarea{
        resize:none;
        overflow: hidden;
    }
    .form-style input[type="button"],
    .form-style input[type="submit"]{
        background: none;
        display: inline-block;
        cursor: pointer;
        font-family: 'Open Sans Condensed', sans-serif;
        font-size: 14px;
        text-decoration: none;
        text-transform: uppercase;
        padding: 10px;
        margin: 10px;
        border: 1px solid white;
        color: white;
        border-radius: 15px;
    }
    .form-style input[type="button"]:hover,
    .form-style input[type="submit"]:hover {
        border: 2px solid white;
    }

    .create {
        color: white;
    }
</style>
