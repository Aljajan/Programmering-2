<template id="animal-detail">
    <div v-if="animal" class="detail-planet-container">
        {{console.log(this.animal)}}
        <h1>{{animal.name}}</h1>
        <img v-if="animal.animalPictureURL" class="cover-image" v-bind:src="animal.animalPictureURL">
        <img v-else class="cover-image" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Icon-round-Question_mark.svg/480px-Icon-round-Question_mark.svg.png">

        <p>In the observation {{observationName}}, was registered the animal {{animal.animalName}}
            with {{animal.gender}} gender, and it has {{animal.diet}} diet.</p>
        <p>
            <a class="button" :href="`/observations/${observationName}`">Go back</a>
        </p>
    </div>
</template>
<script>
    Vue.component("animal-detail", {
        template: "#animal-detail",
        data: () => ({
            animal: null,
            observationName: "",
        }),
        created() {
            const observationId = this.$javalin.pathParams["observation-id"];
            this.observationName= this.$javalin.pathParams["observation-id"];
            fetch(`/api/observations/${observationId}/animal`)
                .then(res => res.json())
                .then(res => this.animal = res)
                .catch(() => alert("Error while fetching animal"));
        }
    });
</script>
<style>
    ul{
        color:white;
    }
    div.detail-planet-container > p {
        max-width: 30em;
    }
    div.detail-planet-container{
        padding-top: 10px;
        overflow: hidden;
        width: 500px;
        background-color: #000000;
        color: white;
        margin: 0 auto;
        opacity: 0.96;
        text-align: center;
        -webkit-box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.25);
        -moz-box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.25);
        box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.25);
    }

    img.planet-cover-image {
        height: 320px;
        width: 320px;
        padding-bottom: 20px;
    }

    .button {
        padding: 10px;
        margin: 10px;
        border: 1px solid white;
        color: white;
        border-radius: 15px;
    }

    button a{
        color: white;
        text-decoration: none;
        font-weight: bold;
    }

    .button:hover{
        border: 2px solid white;
    }

</style>