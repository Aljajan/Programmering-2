<template id="observation-detail">
    <div class="content-wrapper">
        <div v-if="observation" class="detail-observation-container">
            <img v-if="observation.pictureURL" class="cover-image" v-bind:src="observation.pictureURL">
            <img v-else class="cover-image" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Icon-round-Question_mark.svg/480px-Icon-round-Question_mark.svg.png">

            {{console.log(this.planetSystem)}}

            <h1>{{observation.name}}</h1>
            <p>In the {{observation.name}} with a {{observation.id}} id, was registered a {{observation.numberOfAnimals}} of {{animal.animalName}} at the location {{location.locationName}} with the following comments:{{observation.comment}}.</p>

            <p><a class="button" class="add" :href="`/observations/${observation.name}/create`">Create</a>
            <a class="button"  :href="`/api/observations/${observation.name}/delete`">Delete</a>
            <a class="button"  :href="`/observations/${observation.name}/update`">Edit</a></p>
        </div>

        <ul class="animal-overview">
            <li>
                <a v-if="observation" class="link-to-animal-details" :href="`/observations/${observation.name}/animal`">
                    <div class="single-animal-container" >
                        <h1>{{animal.animalName}}</h1>
                        <img v-if="animal.animalPictureURL" class="animal-image" v-bind:src="animal.animalPictureURL">
                        <img v-else class="list-image" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Icon-round-Question_mark.svg/480px-Icon-round-Question_mark.svg.png">
                    </div>
                </a>
            </li>
        </ul>
    </div>
</template>
<script>
    Vue.component("observation-detail", {
        template: "#observation-detail",
        data: () => ({
            observation: null,
            animal: null,
            location: null,
        }),
        created() {
            const observationId = this.$javalin.pathParams["observation-id"];

            fetch(`/api/observations/${observationId}`)
                .then(res => res.json())
                .then(res => {
                    this.observation= res
                    this.animal = this.observation.animal
                    this.location = this.observation.location
                })
                .catch(() => alert("Error while fetching planet system"))
        }
    });
</script>
<style>

    div.detail-observation-container{
        padding: 10px;
        overflow: hidden;
        width: 750px;
        margin: 0 auto;
        background-color: rgba(20, 20, 20, 0.98);
        opacity: 0.96;
        color: white;
        -webkit-box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.25);
        -moz-box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.25);
        box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.25);
    }

    div.single-animal-container{
        overflow: hidden;
        color: white;
        background-color: rgba(0, 0, 0, 0.98);
        margin: 0 auto;
        opacity: 0.96;
        text-align: center;
    }


    img.cover-image {
        height: auto;
        width: 50%;
        margin: 5px;
        float: left;
    }

    img.animal-image {
        width: 140px;
        padding-bottom: 20px;
        transition: transform .2s;
    }

    .animal-image:hover{
        transform: scale(1.1);
    }

    h1{
        font-size:18px;
        padding-top: 10px;
    }

    .link-to-animal-details{
        width: 400px;
        height:100px;
        text-decoration: none;
        color:black;
    }

    .button {
        padding: 10px;
        margin: 10px;
        border: 1px solid white;
        color: white;
        border-radius: 15px;
    }

    button a{
        color: white;
        text-decoration: none;
        font-weight: bold;
    }

    .button:hover{
        border: 2px solid white;
    }

</style>
