package no.hiof.almuthanna.oblig6.model;

public class Bird extends Animal {
    private double wingLength;
    private String abilityToFly;

    public Bird() {
    }

    public Bird(String animalName, String scientificGroup, String gender, String diet, String animalPictureURL, double wingLength, String abilityToFly) {
        super(animalName, scientificGroup, gender, diet, animalPictureURL);
        this.wingLength = wingLength;
        this.abilityToFly = abilityToFly;
    }

    public double getWingLength() {
        return wingLength;
    }

    public String getAbilityToFly() {
        return abilityToFly;
    }

    public void setWingLength(double wingLength) {
        this.wingLength = wingLength;
    }

    public void setAbilityToFly(String abilityToFly) {
        this.abilityToFly = abilityToFly;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(", a wing with %.0f CM long and ability to fly: %s.", wingLength, abilityToFly);
    }
}
