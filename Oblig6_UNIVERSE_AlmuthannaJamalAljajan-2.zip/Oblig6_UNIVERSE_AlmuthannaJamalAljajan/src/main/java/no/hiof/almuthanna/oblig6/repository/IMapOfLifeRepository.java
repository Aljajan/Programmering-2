package no.hiof.almuthanna.oblig6.repository;

import no.hiof.almuthanna.oblig6.model.Animal;
import no.hiof.almuthanna.oblig6.model.Observation;

import java.util.ArrayList;
import java.util.List;

public interface IMapOfLifeRepository {
    void readFromFile(String fileName);

    void writeToFile(List<Observation> observationList, String fileName);

    Observation getObservation(String observationName);

    ArrayList<Observation> getObservations();

    Animal getAnimal(String observationName);

    void deleteObservation(String observationName);

    void creatObservation(String[] formList);

    void updateObservation(String observationName, String[] formList);
}
