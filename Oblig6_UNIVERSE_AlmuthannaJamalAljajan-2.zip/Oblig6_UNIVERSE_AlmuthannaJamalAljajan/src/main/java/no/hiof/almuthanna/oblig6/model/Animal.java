package no.hiof.almuthanna.oblig6.model;

import org.jetbrains.annotations.NotNull;


public abstract class Animal implements Comparable<Animal> {
    private String animalName;
    private String scientificGroup;
    private String gender;
    private String diet;
    private String animalPictureURL;

    public Animal() {
    }

    public Animal(String animalName, String scientificGroup, String gender, String diet, String animalPictureURL) {
        this.animalName = animalName;
        this.scientificGroup = scientificGroup;
        this.gender = gender;
        this.diet = diet;
        this.animalPictureURL = animalPictureURL;
    }

    public String getAnimalName() {
        return animalName;
    }

    public String getScientificGroup() {
        return scientificGroup;
    }

    public String getGender() {
        return gender;
    }

    public String getDiet() {
        return diet;
    }

    public String getAnimalPictureURL() {
        return animalPictureURL;
    }

    public void setAnimalName(String animalName) {
        this.animalName = animalName;
    }

    public void setScientificGroup(String scientificGroup) {
        this.scientificGroup = scientificGroup;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setDiet(String diet) {
        this.diet = diet;
    }

    public void setAnimalPictureURL(String animalPictureURL) {
        this.animalPictureURL = animalPictureURL;
    }

    @Override
    public int compareTo(@NotNull Animal animal) {
        return this.animalName.compareTo(animal.getAnimalName());
    }

    public String toString() {
        return String.format("%s has a %s gender, a %s diet", animalName, gender, diet);
    }
}
