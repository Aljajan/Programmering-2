package no.hiof.almuthanna.oblig6.model;

public class Planet {
    private String name;
    private String planetSystemName;

    public Planet() {
    }

    public Planet(String name, String planetSystemName) {
        this.name = name;
        this.planetSystemName = planetSystemName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPlanetSystemName() {
        return planetSystemName;
    }

    public void setPlanetSystemName(String planetSystemName) {
        this.planetSystemName = planetSystemName;
    }

    @Override
    public String toString() {
        return String.format("The planet %s is in the %s.", name, planetSystemName);
    }
}
