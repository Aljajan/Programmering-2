package no.hiof.almuthanna.oblig6.model;

public class Invertebrate extends Animal {
    private String invertebrateType;
    private String color;

    public Invertebrate() {
    }

    public Invertebrate(String animalName, String scientificGroup, String gender, String diet, String animalPictureURL, String invertebrateType, String color) {
        super(animalName, scientificGroup, gender, diet, animalPictureURL);
        this.invertebrateType = invertebrateType;
        this.color = color;
    }

    public String getInvertebrateType() {
        return invertebrateType;
    }

    public String getColor() {
        return color;
    }

    public void setInvertebrateType(String invertebrateType) {
        this.invertebrateType = invertebrateType;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(", a type of %s and a %s color of skin.", invertebrateType, color);
    }
}
