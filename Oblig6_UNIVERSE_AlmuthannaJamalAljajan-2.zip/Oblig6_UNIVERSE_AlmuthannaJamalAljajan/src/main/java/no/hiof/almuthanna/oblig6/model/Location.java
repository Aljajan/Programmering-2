package no.hiof.almuthanna.oblig6.model;

import java.util.ArrayList;

public class Location {
    private String locationName;
    private Planet planet;
    private double latitude;
    private double longitude;
    private ArrayList<Biom> biomes = new ArrayList<>();
    private static int numberOfLocations;

    public Location() {

    }

    public Location(Planet planet, double latitude, double longitude) {
        this.locationName = "loc" + numberOfLocations++;
        this.planet = planet;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getLocationName() {
        return locationName;
    }

    public Biom getBiom(String biomName) {
        for (Biom biom : biomes) {
            if (biom.getName().equals(biomName))
                return biom;
        }
        return null;
    }

    public ArrayList<Biom> getBiomes() {
        return biomes;
    }

    public Planet getPlanet() {
        return planet;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public static int getNumberOfLocations() {
        return numberOfLocations;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public void setBiom(Biom biom) {
        biomes.add(biom);
    }

    public void setBiomes(ArrayList<Biom> biomes) {
        this.biomes = biomes;
    }

    public void setPlanet(Planet planet) {
        this.planet = planet;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    @Override
    public String toString() {
        return String.format("%s has %d biomes on the planet %s in %f latitude and %f longitude.", locationName, biomes.size(), planet.getName(), latitude, longitude);
    }
}
