package no.hiof.almuthanna.oblig6.repository;

import no.hiof.almuthanna.oblig6.model.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MapOfLifeCSVRepository implements IMapOfLifeRepository {

    private ArrayList<Observation> observations = new ArrayList<>();
    private String csvFile;

    public MapOfLifeCSVRepository(String csvFile) {
        this.csvFile = csvFile;
        readFromFile(csvFile);
    }

    @Override
    public void readFromFile(String fileName) {
        Location location;
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while (( line = bufferedReader.readLine() ) != null) {
                ArrayList<Biom> biomes = new ArrayList<>();
                String[] deler = line.split(",");
                String[] biomesParts = deler[14].split("-");
                for (String biomParts : biomesParts) {
                    String[] parts = biomParts.split(":");
                    Biom biom = new Biom(parts[1]);
                    biomes.add(biom);
                }
                location = new Location(new Planet(deler[10], deler[11]), Double.parseDouble(deler[12]), Double.parseDouble(deler[13]));
                location.setBiomes(biomes);
                if (deler[3].equals("bird")) {
                    observations.add(new Observation(deler[1], new Bird(deler[2], deler[3], deler[4], deler[5], deler[6], Double.parseDouble(deler[7]), deler[8])
                            , location, LocalDate.parse(deler[15]), Integer.parseInt(deler[16]), deler[17], deler[18]));
                } else if (deler[3].equals("amphibian")) {
                    observations.add(new Observation(deler[1], new Amphibian(deler[2], deler[3], deler[4], deler[5], deler[6], deler[7], Integer.parseInt(deler[8]))
                            , location, LocalDate.parse(deler[15]), Integer.parseInt(deler[16]), deler[17], deler[18]));
                } else if (deler[3].equals("invertebrate")) {
                    observations.add(new Observation(deler[1], new Invertebrate(deler[2], deler[3], deler[4], deler[5], deler[6], deler[7], deler[8])
                            , location, LocalDate.parse(deler[15]), Integer.parseInt(deler[16]), deler[17], deler[18]));
                }
            }
        } catch (IOException o) {
            o.fillInStackTrace();

        }

    }

    @Override
    public void writeToFile(List<Observation> observations, String fileName) {
        try (FileWriter fileWriter = new FileWriter(fileName, false);) {
            for (Observation observation : observations) {
                fileWriter.write(observation.getId() + "," + observation.getName() + "," + observation.getAnimal().getAnimalName() + "," +
                        observation.getAnimal().getScientificGroup() + "," + observation.getAnimal().getGender() + "," +
                        observation.getAnimal().getDiet() + "," + observation.getAnimal().getAnimalPictureURL() + ",");
                if (observation.getAnimal() instanceof Bird) {
                    Bird bird = (Bird) observation.getAnimal();
                    fileWriter.write(bird.getWingLength() + "," + bird.getAbilityToFly() + ",");
                } else if (observation.getAnimal() instanceof Amphibian) {
                    Amphibian amphibian = (Amphibian) observation.getAnimal();
                    fileWriter.write(amphibian.getBreathingSystem() + "," + amphibian.getNumberOfLegs() + ",");
                } else if (observation.getAnimal() instanceof Invertebrate) {
                    Invertebrate invertebrate = (Invertebrate) observation.getAnimal();
                    fileWriter.write(invertebrate.getInvertebrateType() + "," + invertebrate.getColor() + ",");
                }
                fileWriter.write(observation.getLocation().getLocationName() + "," + observation.getLocation().getPlanet().getName() +
                        "," + observation.getLocation().getPlanet().getPlanetSystemName() + ","
                        + observation.getLocation().getLatitude() + "," + observation.getLocation().getLongitude() + ",");
                ArrayList<Biom> biomes = observation.getLocation().getBiomes();
                for (int i = 0; i < biomes.size(); i++) {
                    if (i == 0 && biomes.size() == 1)
                        fileWriter.write(biomes.get(i).getName() + ":" + biomes.get(i).getType());
                    else if (i == 0)
                        fileWriter.write(biomes.get(i).getName() + ":" + biomes.get(i).getType());
                    else
                        fileWriter.write("-" + biomes.get(i).getName() + ":" + biomes.get(i).getType());
                }

                fileWriter.write("," + observation.getDate().toString() + "," + observation.getNumberOfAnimals()
                        + "," + observation.getPictureURL() + "," + observation.getComment() + "\n");
            }

        } catch (IOException e) {
            e.fillInStackTrace();
        }

    }


    @Override
    public Observation getObservation(String observationName) {
        for (Observation observation : observations) {
            if (observation.getName().equals(observationName))
                return observation;
        }

        return null;
    }

    @Override
    public ArrayList<Observation> getObservations() {
        return new ArrayList<>(observations);
    }

    @Override
    public Animal getAnimal(String observationName) {
        return getObservation(observationName).getAnimal();
    }

    @Override
    public void deleteObservation(String observationName) {
        Observation observation = getObservation(observationName);
        observations.remove(observation);
        writeToFile(observations, csvFile);
    }


    @Override
    public void creatObservation(String[] formList) {
        observations.add(new Observation(formList[0], createUpdateAnimal(formList), createUpdateLocation(formList),
                LocalDate.parse(formList[13]), Integer.parseInt(formList[14]), formList[15], formList[16]));
        writeToFile(observations, csvFile);
        observations.clear();
        readFromFile(csvFile);
    }


    @Override
    public void updateObservation(String observationName, String[] formList) {
        for (Observation observation : observations) {
            if (observation.getName().equals(observationName)) {
                observation.setName(formList[0]);
                observation.setAnimal(createUpdateAnimal(formList));
                observation.setLocation(createUpdateLocation(formList));
                observation.setDate(LocalDate.parse(formList[13]));
                observation.setNumberOfAnimals(Integer.parseInt(formList[14]));
                observation.setPictureURL(formList[15]);
                observation.setComment(formList[16]);
                writeToFile(observations, csvFile);
            }
        }
    }

    public Location createUpdateLocation(String[] formList) {
        ArrayList<Biom> biomes = new ArrayList<>();
        String[] biomesParts = formList[12].split("-");
        for (String biomPart : biomesParts) {
            Biom biom = new Biom(biomPart);
            biomes.add(biom);
        }
        Location location = new Location(new Planet(formList[8], formList[9]), Double.parseDouble(formList[10]), Double.parseDouble(formList[11]));
        location.setBiomes(biomes);
        return location;
    }

    public Animal createUpdateAnimal(String[] formList) {
        if (formList[2].equals("bird")) {
            return new Bird(formList[1], formList[2], formList[3], formList[4], formList[5], Double.parseDouble(formList[6]), formList[7]);
        } else if (formList[2].equals("amphibian")) {
            return new Amphibian(formList[1], formList[2], formList[3], formList[4], formList[5], formList[6], Integer.parseInt(formList[7]));
        } else {
            return new Invertebrate(formList[1], formList[2], formList[3], formList[4], formList[5], formList[6], formList[7]);

        }
    }
}

