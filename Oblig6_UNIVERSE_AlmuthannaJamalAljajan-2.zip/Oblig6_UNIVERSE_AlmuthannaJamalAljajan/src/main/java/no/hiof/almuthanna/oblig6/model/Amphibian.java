package no.hiof.almuthanna.oblig6.model;

public class Amphibian extends Animal {
    private String breathingSystem;
    private int numberOfLegs;

    public Amphibian() {
    }

    public Amphibian(String animalName, String scientificGroup, String gender, String diet, String animalPictureURL, String breathingSystem, int numberOfLegs) {
        super(animalName, scientificGroup, gender, diet, animalPictureURL);
        this.breathingSystem = breathingSystem;
        this.numberOfLegs = numberOfLegs;
    }

    public String getBreathingSystem() {
        return breathingSystem;
    }

    public int getNumberOfLegs() {
        return numberOfLegs;
    }

    public void setBreathingSystem(String breathingSystem) {
        this.breathingSystem = breathingSystem;
    }

    public void setNumberOfLegs(int numberOfLegs) {
        this.numberOfLegs = numberOfLegs;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(", a breathing system by %s and %d legs.", breathingSystem, numberOfLegs);
    }
}
