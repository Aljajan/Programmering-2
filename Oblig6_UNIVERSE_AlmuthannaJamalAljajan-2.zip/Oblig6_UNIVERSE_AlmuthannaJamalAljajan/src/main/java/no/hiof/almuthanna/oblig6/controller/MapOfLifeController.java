package no.hiof.almuthanna.oblig6.controller;

import io.javalin.http.Context;
import no.hiof.almuthanna.oblig6.repository.IMapOfLifeRepository;

public class MapOfLifeController {
    private IMapOfLifeRepository iMapOfLifeRepository;

    public MapOfLifeController(IMapOfLifeRepository iMapOfLifeRepository) {
        this.iMapOfLifeRepository = iMapOfLifeRepository;
    }
    public void getAllObservations(Context context) {
        context.json(iMapOfLifeRepository.getObservations());
    }
    public void getObservation(Context context) {
        String observationName = context.pathParam("observation-id");
        context.json(iMapOfLifeRepository.getObservation(observationName));
    }
    public void getAnimal(Context ctx){
        String observationName= ctx.pathParam("observation-id");
        ctx.json(iMapOfLifeRepository.getAnimal(observationName));
    }
    public void deleteObservation(Context ctx) {
        String observationName= ctx.pathParam("observation-id");
       iMapOfLifeRepository.deleteObservation(observationName);
    }
    public void createObservation(Context ctx) {
        iMapOfLifeRepository.creatObservation(formList(ctx));
    }
    public void updateObservation(Context ctx) {
        String observationName = ctx.pathParam("observation-id");
        iMapOfLifeRepository.updateObservation(observationName,formList(ctx));
    }

    public String[] formList(Context ctx) {
        String name = ctx.formParam("name");
        String animalName = ctx.formParam("animalName");
        String animalScientificGroup = ctx.formParam("scientificGroup");
        String animalGender = ctx.formParam("gender");
        String animalDiet = ctx.formParam("diet");
        String animalPictureURL = ctx.formParam("animalPictureURL");
        String animalPro1 = ctx.formParam("animalPro1");
        String animalPro2 = ctx.formParam("animalPro2");
        String planetName = ctx.formParam("planetName");
        String planetSystemName = ctx.formParam("planetSystemName");
        String latitude = ctx.formParam("latitude");
        String longitude = ctx.formParam("longitude");
        String biomes = ctx.formParam("biomes");
        String date = ctx.formParam("date");
        String numberOfAnimals = ctx.formParam("numberOfAnimals");
        String pictureURL = ctx.formParam("pictureURL");
        String comment = ctx.formParam("comment");
        String[] formList = new String[]{name, animalName, animalScientificGroup, animalGender, animalDiet, animalPictureURL, animalPro1,
        animalPro2,planetName,planetSystemName,latitude,longitude,biomes,date,numberOfAnimals,pictureURL,comment};
        return formList;
    }



}
