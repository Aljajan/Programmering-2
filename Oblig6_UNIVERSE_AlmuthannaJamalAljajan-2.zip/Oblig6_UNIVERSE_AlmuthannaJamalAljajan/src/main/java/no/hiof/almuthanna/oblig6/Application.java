package no.hiof.almuthanna.oblig6;

import io.javalin.Javalin;
import io.javalin.plugin.rendering.vue.VueComponent;
import no.hiof.almuthanna.oblig6.controller.MapOfLifeController;
import no.hiof.almuthanna.oblig6.repository.MapOfLifeCSVRepository;

public class Application {
    public static void main(String[] args) {

        Javalin app = Javalin.create().start(5000);
        app.config.enableWebjars();

        String csvFile = "csvFile.csv";

        MapOfLifeCSVRepository mapOfLifeCSVRepository = new MapOfLifeCSVRepository(csvFile);
        MapOfLifeController mapOfLifeController = new MapOfLifeController(mapOfLifeCSVRepository);

        //URL
        app.before("/", ctx -> ctx.redirect("/observations"));
        app.get("/observations", new VueComponent("observations-overview"));
        app.get("/observations/:observation-id", new VueComponent("observation-detail"));
        app.get("/observations/:observation-id/animal", new VueComponent("animal-detail"));
        app.get("/observations/:observation-id/create", new VueComponent("observation-create"));
        app.get("/observations/:observation-id/update", new VueComponent("observation-update"));


        // Api
        app.get("api/observations", mapOfLifeController::getAllObservations);
        app.get("api/observations/:observation-id", mapOfLifeController::getObservation);
        app.get("api/observations/:observation-id/animal", mapOfLifeController::getAnimal);
        app.get("api/observations/:observation-id/delete", mapOfLifeController::deleteObservation);
        app.post("api/observations/:observation-id/create", mapOfLifeController::createObservation);
        app.post("api/observations/:observation-id/update", mapOfLifeController::updateObservation);


        // After
        app.after("api/observations/:observation-id/delete", ctx -> {
            ctx.redirect("/observations");
        });
        app.after("/api/observations/:observation-id/create", ctx -> {
            ctx.redirect("/observations");
        });
        app.after("/api/observations/:observation-id/update", ctx -> {
            ctx.redirect("/observations");
        });

    }
}
