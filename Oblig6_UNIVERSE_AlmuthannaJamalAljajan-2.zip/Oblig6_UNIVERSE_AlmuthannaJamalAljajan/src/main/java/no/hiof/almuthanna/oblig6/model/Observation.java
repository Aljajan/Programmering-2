package no.hiof.almuthanna.oblig6.model;

import org.jetbrains.annotations.NotNull;

import java.time.LocalDate;

public class Observation implements Comparable<Observation> {
    private String id;
    private String name;
    private Animal animal;
    private Location location;
    private LocalDate date;
    private int numberOfAnimals;
    private String pictureURL;
    private String comment;
    private static int numberOfObservations;


    public Observation() {
    }

    public Observation(String name, Animal animal, Location location, LocalDate date, int numberOfAnimals, String pictureURL, String comment) {

        this.name = name;
        this.animal = animal;
        this.location = location;
        this.date = date;
        this.numberOfAnimals = numberOfAnimals;
        this.pictureURL = pictureURL;
        this.comment = comment;
        String[] characters = this.name.split("");
        this.id = characters[0].toUpperCase() + numberOfObservations++;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Animal getAnimal() {
        return animal;
    }

    public Location getLocation() {
        return location;
    }

    public LocalDate getDate() {
        return date;
    }

    public int getNumberOfAnimals() {
        return numberOfAnimals;
    }

    public String getPictureURL() {
        return pictureURL;
    }

    public String getComment() {
        return comment;
    }

    public static int getNumberOfObservations() {
        return numberOfObservations;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAnimal(Animal animal) {
        this.animal = animal;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public void setNumberOfAnimals(int numberOfAnimals) {
        this.numberOfAnimals = numberOfAnimals;
    }

    public void setPictureURL(String pictureURL) {
        this.pictureURL = pictureURL;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    @Override
    public int compareTo(@NotNull Observation observation) {
        return this.name.compareTo(observation.getName());
    }

    @Override
    public String toString() {
        return String.format("In the observation with a %s name and a %s id, was registered " +
                        "a %d of %s  on %s at the location %s with the following comments:%s",
                name, id, numberOfAnimals, animal.getAnimalName(), date, location.getLocationName(), comment);
    }
}


