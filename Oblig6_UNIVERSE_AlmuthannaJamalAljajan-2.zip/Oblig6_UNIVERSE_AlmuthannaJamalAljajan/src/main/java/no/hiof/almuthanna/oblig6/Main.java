package no.hiof.almuthanna.oblig6;

import no.hiof.almuthanna.oblig6.model.*;
import no.hiof.almuthanna.oblig6.repository.MapOfLifeCSVRepository;

import java.time.LocalDate;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<Observation> observations = new ArrayList<>();
        ArrayList<Biom> biomes0 = new ArrayList<>();
        biomes0.add(new Biom("coastal areas"));
        biomes0.add(new Biom("Swamps"));
        Location location0 = new Location(new Planet("Jupiter", "Solar System"), 34.802074, 38.996815);
        location0.setBiomes(biomes0);
        observations.add(new Observation("Sirenia", new Amphibian("Dugongidae", "amphibian", "male",
                "carnivorous", "https://upload.wikimedia.org/wikipedia/commons/9/91/Dugong_Marsa_Alam.jpg",
                "lungs", 0), location0, LocalDate.of(2337, 4, 1), 50,
                "https://upload.wikimedia.org/wikipedia/commons/a/aa/Ocean_from_Leblon.jpg", " "));
        ArrayList<Biom> biomes1 = new ArrayList<>();
        biomes1.add(new Biom("rivers"));
        Location location1 = new Location(new Planet("Saturn", "Solar System"), 60.472023, 8.468946);
        location1.setBiomes(biomes1);
        observations.add(new Observation("Anthracotheres", new Amphibian("Hippopotamus", "amphibian", "female",
                "vegetarian", "https://upload.wikimedia.org/wikipedia/commons/f/fa/Hippopotamus_in_San_Diego_Zoo.jpg",
                "lungs", 4), location1, LocalDate.of(2337, 4, 2), 20,
                "https://upload.wikimedia.org/wikipedia/commons/5/5c/Loboc_river.png", " "));
        ArrayList<Biom> biomes2 = new ArrayList<>();
        biomes2.add(new Biom("forests"));
        Location location2 = new Location(new Planet("Neptune", "Solar System"), 12.862807, 30.217636);
        location2.setBiomes(biomes2);
        observations.add(new Observation("Paradisaeidae", new Bird("Bird-of-paradise", "bird", "male",
                "vegetarian", "https://upload.wikimedia.org/wikipedia/commons/c/ce/Raggiana_Bird-of-Paradise_wild_5.jpg",
                20, "yes"), location2, LocalDate.of(2337, 4, 3), 100,
                "https://upload.wikimedia.org/wikipedia/commons/c/cb/Hellyer_Gorge%2C_Tasmania.jpg", " "));
        ArrayList<Biom> biomes3 = new ArrayList<>();
        biomes3.add(new Biom("forests"));
        Location location3 = new Location(new Planet("Uranus", "Solar System"), 30.862807, 9.217636);
        location3.setBiomes(biomes3);
        observations.add(new Observation("Ramphastidae", new Bird("Toucan", "bird", "female",
                "vegetarian", "https://upload.wikimedia.org/wikipedia/commons/0/04/-_panoramio_-_Basa_Roland.jpg",
                30, "yes"), location3, LocalDate.of(2337, 4, 3), 60,
                "https://upload.wikimedia.org/wikipedia/commons/a/a0/Garibaldi_National_Park_-_Garibaldi_Mountain.jpg", " "));
        ArrayList<Biom> biomes4 = new ArrayList<>();
        biomes4.add(new Biom("Oceans"));
        Location location4 = new Location(new Planet("Mars", "Solar System"), 45.042282, 11.511138);
        location4.setBiomes(biomes4);
        observations.add(new Observation("Aeolidioidea", new Invertebrate("Glaucus atlanticus", "invertebrate",
                "male", "carnivorous", "https://upload.wikimedia.org/wikipedia/commons/5/57/Blue_dragon-glaucus_atlanticus_%288599051974%29.jpg",
                "Glaucidae", "blue-black"), location4, LocalDate.of(2337, 4, 4), 40,
                "https://upload.wikimedia.org/wikipedia/commons/0/0a/Spanish_shawl.JPG", " "));
        ArrayList<Biom> biomes5 = new ArrayList<>();
        biomes5.add(new Biom("Oceans"));
        Location location5 = new Location(new Planet("Venus", "Solar System"), 22.042282, 50.511138);
        location5.setBiomes(biomes5);
        observations.add(new Observation("Medusozoa", new Invertebrate("Jellyfish", "invertebrate",
                "unKnown", "carnivorous", "https://upload.wikimedia.org/wikipedia/commons/4/44/Jelly_cc11.jpg",
                "Acraspeda", "Orange"), location5, LocalDate.of(2337, 5, 4), 150,
                "https://upload.wikimedia.org/wikipedia/commons/7/7b/Red_sea_coral_reef.jpg", " "));

        printInformation(observations);

        String csvFile = "csvFile.csv";
        MapOfLifeCSVRepository mapOfLifeCSVRepository = new MapOfLifeCSVRepository(csvFile);
        Thread thread = new Thread(() -> {
            mapOfLifeCSVRepository.writeToFile(observations, csvFile);
            System.out.println(Thread.currentThread().getName());
        });
        thread.start();


    }

    public static void printInformation(ArrayList<Observation> observations) {
        for (Observation observation : observations) {
            System.out.println(observation);
        }
    }
}

