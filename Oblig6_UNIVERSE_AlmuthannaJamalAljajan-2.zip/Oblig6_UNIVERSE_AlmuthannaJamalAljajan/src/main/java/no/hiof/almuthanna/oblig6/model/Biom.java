package no.hiof.almuthanna.oblig6.model;

public class Biom {
    private String name;
    private String type;
    private static int numberOfBiomes;

    public Biom() {

    }

    public Biom(String type) {
        name = "bio" + numberOfBiomes++;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return String.format("The biom has a name %s and a %s type.", name, type);
    }
}
