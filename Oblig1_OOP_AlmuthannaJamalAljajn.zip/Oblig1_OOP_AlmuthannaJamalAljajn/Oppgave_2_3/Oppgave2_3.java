public class Oppgave2_3 {

  public static void main(String[] args) {
    Planet mercuryPlanet = new Planet ("Mercury", 2440, 3.8);
    Planet venusPlanet = new Planet ("Venus", 6050, 8.8);
    Planet earthPlanet = new Planet ("Earth", 6400, 9.8);
    Planet marsPlanet = new Planet("Mars", 3389.5, 3.711);
    Planet jupiterPlanet = new Planet ("Jupiter", 71400, 25);
    Planet saturnPlanet = new Planet ("Saturn", 60400, 10.4);
    Planet uranusPlanet = new Planet ("Uranus", 23600, 10.4);
    Planet neptunePlanet = new Planet ("Neptune", 22300, 13.8);

    mercuryPlanet.printPlanetInformation();
    venusPlanet.printPlanetInformation();
    earthPlanet.printPlanetInformation();
    marsPlanet.printPlanetInformation();
    jupiterPlanet.printPlanetInformation();
    saturnPlanet.printPlanetInformation();
    uranusPlanet.printPlanetInformation();
    neptunePlanet.printPlanetInformation();

  }}
