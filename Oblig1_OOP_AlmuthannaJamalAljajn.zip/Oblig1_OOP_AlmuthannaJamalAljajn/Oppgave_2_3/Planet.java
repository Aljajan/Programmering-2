public class Planet {

    private String navn;
    private double radius;
    private double gravitasjon;

    public Planet (String navn, double radius, double gravitasjon) {
        this.navn = navn;
        this.radius = radius;
        this.gravitasjon = gravitasjon;

      }
      public String getNavn() {
      return navn;
      }

      public double getRadius() {
      return radius;
      }

      public double getGravitasjon() {
      return gravitasjon;
      }

      public void setNavn(String navn) {
        this.navn = navn;
      }

      public void setRadius(double radius) {
        this.radius = radius;
      }

      public void setGravitasjon(double gravitasjon) {
        this.gravitasjon = gravitasjon;
      }
      public void printPlanetInformation() {
        System.out.println("Planeten " + navn +" har en radius pa " + radius + " km og en gravitasjon pa " + gravitasjon + " m/s^2");

    }

}
