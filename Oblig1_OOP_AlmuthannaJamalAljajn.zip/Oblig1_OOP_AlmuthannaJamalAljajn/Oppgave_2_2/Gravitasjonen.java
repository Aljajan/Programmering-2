public class Gravitasjonen {

public static void main (String [] args){
double mittVektPaJorden = 70;
double mittVektPaManen = mittVektPaJorden * 0.17;
System.out.println ("Mitt vekt pa manen er " + mittVektPaManen + " kg.");

}
}
