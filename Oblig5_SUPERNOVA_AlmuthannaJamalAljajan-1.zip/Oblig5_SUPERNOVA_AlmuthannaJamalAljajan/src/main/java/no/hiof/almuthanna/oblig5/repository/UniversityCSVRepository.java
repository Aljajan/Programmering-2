package no.hiof.almuthanna.oblig5.repository;


import no.hiof.almuthanna.oblig5.model.Planet;
import no.hiof.almuthanna.oblig5.model.PlanetSystem;
import no.hiof.almuthanna.oblig5.model.Star;

import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

public class UniversityCSVRepository implements IUniversityRepository {

    HashMap<String, PlanetSystem> planetSystemHashMap = new HashMap<>();
    private String csvFile;

    public UniversityCSVRepository(String csvFile) {
        this.csvFile = csvFile;
        readFromCsv(csvFile);
    }

    public void readFromCsv(String csvFile) {
        PlanetSystem planetSystem;
        Star star = new Star();
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(csvFile));) {
            String linje;
            while (( linje = bufferedReader.readLine() ) != null) {
                String[] deler = linje.split(",");
                if (!planetSystemHashMap.containsKey(deler[0])) {
                    star = new Star(deler[2], Double.parseDouble(deler[3]),
                            Double.parseDouble(deler[4]), Double.parseDouble(deler[5]), deler[6]);
                    planetSystem = new PlanetSystem(deler[0], star, deler[1]);
                    planetSystem.setPlanet(new Planet(deler[7], Double.parseDouble(deler[8]), Double.parseDouble(deler[9]), Double.parseDouble(deler[10]),
                            Double.parseDouble(deler[11]), Double.parseDouble(deler[12]), star, deler[13]));
                    planetSystemHashMap.put(deler[0], planetSystem);
                } else {
                    planetSystemHashMap.get(deler[0]).setPlanet(new Planet(deler[7], Double.parseDouble(deler[8]), Double.parseDouble(deler[9]), Double.parseDouble(deler[10]),
                            Double.parseDouble(deler[11]), Double.parseDouble(deler[12]), star, deler[13]));
                }
            }
        } catch (IOException o) {
            o.fillInStackTrace();

        }


    }


    public void writeToCsv(String csvFile) {
        try (FileWriter fileWriter = new FileWriter(csvFile, false);) {
            for (PlanetSystem planetSystem : planetSystemHashMap.values()) {
                for (int j = 0; j < planetSystem.getPlanets().size(); j++) {
                    Planet planet = planetSystem.getPlanets().get(j);
                    fileWriter.write(planetSystem.getName() + "," + planetSystem.getPictureUrl() + "," +
                            planetSystem.getCenterStar().getName() + "," + planetSystem.getCenterStar().getMass() + "," +
                            planetSystem.getCenterStar().getRadius() + "," + planetSystem.getCenterStar().getEffectiveTemperature() + "," +
                            planetSystem.getCenterStar().getPictureUrl() + "," + planet.getName() + "," + planet.getMass() + "," + planet.getRadius() + "," +
                            planet.getSemiMajorAxis() + "," + planet.getEccentricity() + "," + planet.getOrbitalPeriod() + "," + planet.getPictureUrl() + "\n");
                }
            }

        } catch (FileNotFoundException e) {
            e.fillInStackTrace();
        } catch (IOException e) {
            e.fillInStackTrace();

        }

    }


    @Override
    public PlanetSystem getPlanetSystem(String planetSystemName) {
        Collection<PlanetSystem> planetValues = planetSystemHashMap.values();
        ArrayList<PlanetSystem> planetSystems = new ArrayList<PlanetSystem>(planetValues);
        for (PlanetSystem planetSystem : planetSystems) {
            if (planetSystem.getName().equals(planetSystemName)) {
                return planetSystem;
            }
        }
        return null;
    }

    @Override
    public ArrayList<PlanetSystem> getPlanetSystems() {
        Collection<PlanetSystem> planetValues = planetSystemHashMap.values();
        ArrayList<PlanetSystem> planetSystems = new ArrayList<PlanetSystem>(planetValues);
        return planetSystems;
    }

    @Override
    public Planet getPlanet(String planetSystemName, String planetName) {
        return getPlanetSystem(planetSystemName).getPlanet(planetName);
    }

    @Override
    public ArrayList<Planet> getPlanets(String planetSystemName) {
        return getPlanetSystem(planetSystemName).getPlanets();
    }

    @Override
    public void deletePlanet(String planetSystemName, String planetName) {

        getPlanetSystem(planetSystemName).getPlanets().remove(getPlanet(planetSystemName, planetName));
        writeToCsv(csvFile);
    }

    @Override
    public void creatPlanet(String planetSystemName, String[] formList) {
        getPlanets(planetSystemName).add(new Planet(formList[0], Double.parseDouble(formList[1]),
                Double.parseDouble(formList[2]), Double.parseDouble(formList[3]), Double.parseDouble(formList[4]),
                Double.parseDouble(formList[5]), formList[6]));
        writeToCsv(csvFile);
        planetSystemHashMap.clear();
        readFromCsv(csvFile);

    }

    @Override
    public void updatePlanet(String planetSystemName, String planetName, String[] formList) {
        getPlanet(planetSystemName, planetName).updatePlanet(Double.parseDouble(formList[1]),
                Double.parseDouble(formList[2]), Double.parseDouble(formList[3]), Double.parseDouble(formList[4]),
                Double.parseDouble(formList[5]), formList[6]);
        writeToCsv(csvFile);
    }
}

