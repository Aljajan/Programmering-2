package no.hiof.almuthanna.oblig5.repository;


import com.fasterxml.jackson.databind.ObjectMapper;
import no.hiof.almuthanna.oblig5.model.Planet;
import no.hiof.almuthanna.oblig5.model.PlanetSystem;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class UniverseJSONRepository implements IUniversityRepository {
    private List<PlanetSystem> planetSystems;
    private String jsonFile;

    public UniverseJSONRepository(String jsonFile) {
        this.jsonFile = jsonFile;
        readFromJson(jsonFile);
    }


    public void readFromJson(String fileName) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();

            PlanetSystem[] planetSystemssArray = objectMapper.readValue(new File(fileName), PlanetSystem[].class);
            planetSystems = Arrays.asList(planetSystemssArray);
        } catch (IOException e) {
            e.printStackTrace(System.out);
        }

    }


    public void writeToJson(String fileName) {
        try {
            File file = new File(fileName);
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(file, planetSystems);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @Override
    public PlanetSystem getPlanetSystem(String planetSystemName) {
        for (PlanetSystem planetSystem : this.planetSystems) {
            if (planetSystem.getName().equals(planetSystemName)) {
                return planetSystem;
            }
        }

        return null;
    }

    @Override
    public ArrayList<PlanetSystem> getPlanetSystems() {
        return new ArrayList<>(planetSystems);
    }

    @Override
    public Planet getPlanet(String planetSystemName, String planetName) {
        return getPlanetSystem(planetSystemName).getPlanet(planetName);
    }

    @Override
    public ArrayList<Planet> getPlanets(String planetSystemName) {
        return getPlanetSystem(planetSystemName).getPlanets();
    }


    @Override
    public void deletePlanet(String planetSystemName, String planetName) {
        getPlanetSystem(planetSystemName).getPlanets().remove(getPlanet(planetSystemName, planetName));
        writeToJson(jsonFile);

    }

    @Override
    public void creatPlanet(String planetSystemName, String[] formList) {
        getPlanets(planetSystemName).add(new Planet(formList[0], Double.parseDouble(formList[1]),
                Double.parseDouble(formList[2]), Double.parseDouble(formList[3]), Double.parseDouble(formList[4]),
                Double.parseDouble(formList[5]), getPlanetSystem(planetSystemName).getCenterStar(), formList[6]));
        writeToJson(jsonFile);

    }


    @Override
    public void updatePlanet(String planetSystemName, String planetName, String[] formList) {
        getPlanet(planetSystemName, planetName).updatePlanet(Double.parseDouble(formList[1]),
                Double.parseDouble(formList[2]), Double.parseDouble(formList[3]), Double.parseDouble(formList[4]),
                Double.parseDouble(formList[5]), formList[6]);
        writeToJson(jsonFile);

    }
}

