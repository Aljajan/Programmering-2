package no.hiof.almuthanna.oblig5;


import io.javalin.Javalin;
import io.javalin.plugin.rendering.vue.VueComponent;
import no.hiof.almuthanna.oblig5.controller.PlanetController;
import no.hiof.almuthanna.oblig5.controller.PlanetSystemController;
import no.hiof.almuthanna.oblig5.repository.UniverseJSONRepository;
import no.hiof.almuthanna.oblig5.repository.UniverseRepository;
import no.hiof.almuthanna.oblig5.repository.UniversityCSVRepository;

public class Application {
    public static void main(String[] args) {
        Javalin app = Javalin.create().start(9900);
        app.config.enableWebjars();
        app.before("/", ctx -> ctx.redirect("/planet-systems"));

        // Files
        String json100File = "planets_100.json";
        String json4000File = "planets_4000.json";
        String csv100File = "planets_100.csv";
        String csv4000File = "planets_4000.csv";

        // Repository
        UniverseRepository universeRepository = new UniverseRepository();
        UniversityCSVRepository universityCSV100Repository = new UniversityCSVRepository(csv100File);
        UniversityCSVRepository universityCSV4000Repository = new UniversityCSVRepository(csv4000File);
        UniverseJSONRepository universeJSON100Repository = new UniverseJSONRepository(json100File);
        UniverseJSONRepository universeJSON4000Repository = new UniverseJSONRepository(json4000File);

        // Controller
        PlanetSystemController planetSystemController = new PlanetSystemController(universeJSON100Repository);
        PlanetController planetController = new PlanetController(universeJSON100Repository);

        // Thread
        Thread thread1 = new Thread(() -> {
            universeJSON100Repository.writeToJson(json100File);
            System.out.println(Thread.currentThread().getName());
        });
        thread1.start();
        Thread thread2 = new Thread(() -> {
            universityCSV100Repository.writeToCsv(csv100File);
            System.out.println(Thread.currentThread().getName());
        });
        thread2.start();

        //URL

        app.get("/planet-systems", new VueComponent("planet-system-overview"));
        app.get("/planet-systems/:planet-system-id", new VueComponent("planet-system-detail"));
        app.get("/planet-systems/:planet-system-id/planets/:planet-id", new VueComponent("planet-detail"));
        app.get("/planet-systems/:planet-system-id/createplanet", new VueComponent("planet-create"));
        app.get("/planet-systems/:planet-system-id/planets/:planet-id/update", new VueComponent("planet-update"));

        //Api
        app.get("api/planet-systems", planetSystemController::getAllPlanetSystems);
        app.get("api/planet-systems/:planet-system-id", planetSystemController::getPlanetSystem);
        app.get("/api/planet-systems/:planet-system-id/planets", planetController::getPlanets);
        app.get("/api/planet-systems/:planet-system-id/planets/:planet-id", planetController::getPlanet);
        app.get("/api/planet-systems/:planet-system-id/planets/:planet-id/delete", planetController::deletPlanet);
        app.post("/api/planet-systems/:planet-system-id/createplanet", planetController::createPlanet);
        app.post("/api/planet-systems/:planet-system-id/planets/:planet-id/update", planetController::updatePlanet);

        //After
        app.after("/api/planet-systems/:planet-system-id/planets/:planet-id/delete", ctx -> {
            String planetSystem = ctx.pathParam(":planet-system-id");
            ctx.redirect("/planet-systems/" + planetSystem);
        });
        app.after("/api/planet-systems/:planet-system-id/createplanet", ctx -> {
            String planetSystem = ctx.pathParam(":planet-system-id");
            ctx.redirect("/planet-systems/" + planetSystem);
        });
        app.after("/api/planet-systems/:planet-system-id/planets/:planet-id/update", ctx -> {
            String planetSystem = ctx.pathParam(":planet-system-id");
            String planetName = ctx.pathParam("planet-id");
            ctx.redirect("/planet-systems/" + planetSystem + "/planets/" + planetName);
        });

    }
}
