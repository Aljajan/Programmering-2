package no.hiof.almuthanna.oblig5.controller;


import io.javalin.http.Context;
import no.hiof.almuthanna.oblig5.model.Planet;
import no.hiof.almuthanna.oblig5.repository.IUniversityRepository;

import java.util.ArrayList;
import java.util.Collections;

public class PlanetController {
    private IUniversityRepository universityRepository;

    public PlanetController(IUniversityRepository universityRepository) {
        this.universityRepository = universityRepository;
    }

    public void getPlanets(Context context) {
        String planetSystemName = context.pathParam("planet-system-id");
        String sortBy = context.queryParam("sort_by");

        ArrayList<Planet> planets = universityRepository.getPlanets(planetSystemName);

        if (sortBy != null) {
            switch (sortBy) {
                case "name":
                    Collections.sort(planets);
                    break;
                case "mass":
                    planets.sort((o1, o2) -> (int) ( o1.getMass() - o2.getMass() ));
                    break;
                case "radius":
                    planets.sort((o1, o2) -> {
                        if (o1.getRadius() < o2.getRadius())
                            return -1;
                        else if (o1.getRadius() > o2.getRadius())
                            return 1;
                        return 0;
                    });
                    break;
            }
        }


        context.json(planets);
    }

    public void getPlanet(Context context) {
        String planetSystemName = context.pathParam("planet-system-id");
        String planetName = context.pathParam("planet-id");
        Planet planet = universityRepository.getPlanet(planetSystemName, planetName);
        context.json(planet);
    }

    public void deletPlanet(Context context) {
        String planetSystemName = context.pathParam("planet-system-id");
        String planetName = context.pathParam("planet-id");
        universityRepository.deletePlanet(planetSystemName, planetName);
    }

    public void createPlanet(Context ctx) {
        String planetSystemName = ctx.pathParam("planet-system-id");
        universityRepository.creatPlanet(planetSystemName, formList(ctx));


    }

    public void updatePlanet(Context ctx) {
        String planetSystemName = ctx.pathParam("planet-system-id");
        String planetName = ctx.pathParam("planet-id");
        universityRepository.updatePlanet(planetSystemName, planetName, formList(ctx));
    }

    public String[] formList(Context ctx) {
        String formName = ctx.formParam("name");
        String formMass = ctx.formParam("mass");
        String formRadius = ctx.formParam("radius");
        String formSemi = ctx.formParam("semiMajorAxis");
        String formEssen = ctx.formParam("eccentricity");
        String formOrbital = ctx.formParam("orbitalPeriod");
        String formPicture = ctx.formParam("pictureUrl");
        String[] formList = new String[]{formName, formMass, formRadius, formSemi, formEssen, formOrbital, formPicture};
        return formList;
    }
}
